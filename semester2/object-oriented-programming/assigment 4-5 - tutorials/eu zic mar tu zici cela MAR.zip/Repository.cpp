#include "Repository.h"
#include "DynamicVector.h"

void Repository::addTutorial(const Tutorials& tutorial)
{
    this->tutorials.add(tutorial);
}

void Repository::deleteTutorial(const Tutorials& tutorial)
{
    this->tutorials.delete_(tutorial);
}

void Repository::updateTutorial(const Tutorials& tutorial)
{
    this->tutorials.update(tutorial);
}

void Repository::

Tutorial(const Tutorials& tutorial)
{
    this->tutorials.update(tutorial);
}

DynamicVector<Tutorials> Repository::getAll() const
{
    return this->tutorials;
}

int Repository::getSize() const
{
    return this->tutorials.getSize();
}
