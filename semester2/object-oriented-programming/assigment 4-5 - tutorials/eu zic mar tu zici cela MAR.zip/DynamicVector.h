#pragma once
#include "tutorials.h"

//typedef Tutorials TElem;
template <typename T>
class DynamicVector
{
private:
	T* elems;
	int capacity, size;

	void resize();

public:
	DynamicVector(int cap = 10);
	~DynamicVector();

	DynamicVector(const DynamicVector& v);
	DynamicVector& operator=(const DynamicVector& v);

	void add(const T& element);
	void delete_(const T& element);
	void update(const T& element);

	T getElement(int i) const;
	int getSize() const;
};

template class DynamicVector<Tutorials>;
