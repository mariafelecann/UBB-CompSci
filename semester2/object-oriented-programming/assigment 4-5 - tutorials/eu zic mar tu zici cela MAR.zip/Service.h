#pragma once
#include "Repository.h"

class Service
{
private:
	Repository& repo;

public:
	Service(Repository& _repo);
	void addTutorialService(const Tutorials& t);
	void deleteTutorialService(const Tutorials& t);
	void updateTutorialService(const Tutorials& t);
	int getSize() const;
	Repository getRepo() const;
};


