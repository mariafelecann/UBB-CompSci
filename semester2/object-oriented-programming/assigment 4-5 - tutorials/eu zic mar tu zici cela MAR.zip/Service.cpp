#include "Service.h"

Service::Service(Repository& _repo): repo {_repo}
{
}

void Service::addTutorialService(const Tutorials& tutorial)
{

	this->repo.addTutorial(tutorial);
}

void Service::deleteTutorialService(const Tutorials& tutorial)
{

	this->repo.deleteTutorial(tutorial);
}

void Service::updateTutorialService(const Tutorials& tutorial)
{
	this->repo.updateTutorial(tutorial);
}
int Service::getSize() const
{
	return this->repo.getSize();
}

Repository Service::getRepo() const
{
	return this->repo;
}
