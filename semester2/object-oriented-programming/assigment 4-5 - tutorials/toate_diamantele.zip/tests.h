#pragma once
void test_service_add_tutorial();
void test_service_delete_tutorial();
void test_service_update_tutuorial();
void test_get_size();
void test_get_tutorials_of_presenter();
void test_get_repo();
void test_all();
template<typename Tutorial>
void test_dynamic_vector();
template<typename Tutorial>
void test_resize();

