#pragma once
#include <iostream>
#include <string>
#include "service.h"
#include "tutorials.h"
#include "repository.h"


void add_a_tutorial_ui(Service& service);
void delete_a_tutorial_ui(Service& service);
void update_a_tutorial_ui(Service& service);
void see_all_tutorials(Service& service);

void see_tutorials_of_a_presenter(Service& service, Service& service_watch_list, std::string presenter);
void add_tutorial_to_watch_list(Service& service, Service& service_watch_list);
int see_next_tutorial(Service& service, Service& service_watch_list, std::string name, int& last_time);
void delete_tutorial_from_watch_list(Service& service, Service& service_watch_list);
void see_watch_list(Service& service, Service& service_watch_list);

void print_administrator_mode_options();
void run_administrator_console(Service& service);
void print_user_mode_options();
void run_user_console(Service& service, Service& service_watch_list);
void choose_user_or_administrator_mode(Service& service, Service& service_watch_list);


