#pragma once
#include "tutorials.h"
#include "DynamicVector.h"

class Repository
{
private:
	DynamicVector<Tutorials> tutorials;

public:
	void addTutorial(const Tutorials& tutorial);
	void deleteTutorial(const Tutorials& tutorial);
	void updateTutorial(const Tutorials& tutorial);
	void Tutorial(const Tutorials& tutorial);
	DynamicVector<Tutorials> getAll() const;
	int getSize() const;
};

