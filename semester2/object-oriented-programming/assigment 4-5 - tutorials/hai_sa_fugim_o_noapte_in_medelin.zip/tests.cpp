#include "DynamicVector.h"
#include "Repository.h"
#include "Service.h"
#include "tutorials.h"

#include <assert.h>
/*
void testDynamicVector()
{
	DynamicVector<T> vector{ 1 };

	Tutorials t("TITLE", "PRESENTER", "LINK", 30, 42, 100);

	assert(vector.getSize() == 0);

	vector.add(t);

	assert(vector.getSize() == 1);

	DynamicVector<T> v2 = vector;
	//DynamicVector v2{ vector };
	assert(v2.getSize() == 1);

	DynamicVector<T> v3{};
	assert(v3.getSize() == 0);
	v3 = v2;
	assert(v3.getSize() == 1);
	Tutorials tutorial2{ "TITLE2", "PRESENTER2", "LINK2", 31, 43, 101 };
	v3.add(tutorial2);
	assert(v3.getSize() == 2);

}
void testAddFunction()
{
	
	Tutorials t1{ "T1", "P1", "L1", 30, 8, 100 };
	Tutorials t2{ "T2", "P2", "L2", 5, 5, 200 };

	Repository repo{};
	repo.addTutorial(t1);
	repo.addTutorial(t2);

	Service serv{ repo };
	assert(serv.getSize() == 2);

	Tutorials t3{ "T3", "P3", "L3", 20, 20, 300 };
	repo.addTutorial(t3);
	assert(serv.getSize() == 3);
}
*/