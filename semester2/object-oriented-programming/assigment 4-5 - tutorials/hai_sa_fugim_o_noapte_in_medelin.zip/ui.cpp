#include <string>
#include <iostream>
#include "Service.h"
#include "tutorials.h"
#include "Repository.h"
#include "ui.h"
#include "DynamicVector.h"

void add_a_tutorial_ui()
{
	std::string title, presenter, link;
	int duration_minutes, duration_seconds, number_of_likes;
	std::cout << "Please write the title, presenter, link, duration and number of likes of the new tutorial" << std::endl;
	std::cout << " The title is? ";
	getline(std::cin, title);
	std::cout << " The presenter is? ";
	getline(std::cin, presenter);
	std::cout << " The link is? ";
	getline(std::cin, link);
	std::cout << " The duration is? Please first write the minutes ";
	std::cin >> duration_minutes;
	std::cout << "Now write the remaining seconds ";
	std::cin >> duration_seconds;
	std::cout << " The number of likes is? ";
	std::cin >> number_of_likes;
	Tutorials t{ title, presenter, link, duration_minutes, duration_seconds, number_of_likes };
	Repository repo{};
	repo.addTutorial(t);
	//Service service_{ repo { } };
	//service_.addTutorial(t);
}

void delete_a_tutorial_ui()
{
	std::string title, presenter, link;
	int duration_minutes, duration_seconds, number_of_likes;
	std::cout << "please write the title and presenter of the tutorial you want to delete" << std::endl;
	std::cout << " The title is? ";
	getline(std::cin, title);
	std::cout << " The presenter is? ";
	getline(std::cin, presenter);
	std::cout << " The link is? ";
	getline(std::cin, link);
	std::cout << " The duration is? Please first write the minutes ";
	std::cin >> duration_minutes;
	std::cout << "Now write the remaining seconds ";
	std::cin >> duration_seconds;
	std::cout << " The number of likes is? ";
	std::cin >> number_of_likes;
	Tutorials tutorial{ title, presenter, link, duration_minutes, duration_seconds, number_of_likes };
	Repository repo{};
	//Service::deleteTutorial(t);
	repo.deleteTutorial(tutorial);
}

void update_a_tutorial_ui()
{
	std::string title, presenter, link;
	int duration_minutes, duration_seconds, number_of_likes;
	std::cout << "Please write the title of the tutorial you want to update" << std::endl;
	std::cout << " The title is? ";
	getline(std::cin, title);

	std::cout << " Write the old presenter if you do not wish to update it or the new one otherwise " << std::endl;
	getline(std::cin, presenter);
	std::cout << " Write the old link if you do not wish to update it or the new one otherwise ";
	getline(std::cin, link);
	std::cout << " Write the old duration in minutes if you do not wish to update it or the new one otherwise ";
	std::cin >> duration_minutes;
	std::cout << " Write the old duration in seconds if you do not wish to update it or the new one otherwise ";
	std::cin >> duration_seconds;
	std::cout << " Write the old number of likes if you do not wish to update it or the new one otherwise ";
	std::cin >> number_of_likes;
	Tutorials t{ title, presenter, link, duration_minutes, duration_seconds, number_of_likes };
	Repository repo{};
	repo.updateTutorial(t);
}

void see_all_tutorials()
{
	Repository repo{};
	Tutorials tutorial;
	DynamicVector<Tutorials> list= repo.getAll();
	for (int i = 0; i < list.getSize(); i++)
	{
		tutorial = list.getElement(i);
		std::cout << tutorial.getTitle() << " " << tutorial.getPresenter() << " " << tutorial.getLink() << " " << tutorial.getDurationMinutes() << " " << tutorial.getDurationSeconds()<<std::endl;
	}

}
void see_tutorials_of_a_presenter()
{

}
void add_tutorial_to_watch_list()
{

}
void see_next_tutorial()
{

}
void delete_tutorial_from_watch_list()
{

}
void see_watch_list()
{

}
void print_administrator_mode_options()
{
	std::cout << "Here are the administrator options: " << std::endl;
	std::cout << " 1. Add a tutorial " << std::endl;
	std::cout << " 2. Delete a tutorial " << std::endl;
	std::cout << " 3. Update a tutorial " << std::endl;
	std::cout << " 4. See all tutorials" << std::endl;
	std::cout << " 5. Go back and choose another mode" << std::endl;

	std::cout << " Your option is? " << std::endl << " > ";
}

void run_administrator_console()
{
	print_administrator_mode_options();
	int option;
	std::cin >> option;
	while (option != 5)
	{
		if (option == 1)
			add_a_tutorial_ui();
		else
			if (option == 2)
				delete_a_tutorial_ui();
			else
				if (option == 3)
					///update_a_tutorial_ui();
					std::cout << "not implemented";
				else
					if (option == 4)
						see_all_tutorials();
					else
						std::cout << "Invalid input" << std::endl;
		print_administrator_mode_options();
		std::cin >> option;

	}
}

void print_user_mode_options()
{
	std::cout << "Here are the user options" << std::endl;
	std::cout << "1. See the tutorials of a certain presenter" << std::endl;
	std::cout << "2. Add tutorial to watchlist" << std::endl;
	std::cout << "3. Show next tutorial" << std::endl;
	std::cout << "4. Delete a tutorial from the watchlist" << std::endl;
	std::cout << "5. See the watchlist" << std::endl;
	std::cout << "6. Go back and choose another mode" << std::endl;
	std::cout << "Your option is?";
}
void run_user_console()
{
	print_user_mode_options();
	int option;
	std::cin >> option;
	while (option != 6)
	{
		if (option == 1)
			see_tutorials_of_a_presenter();
		else
			if (option == 2)
				add_tutorial_to_watch_list();
			else
				if (option == 3)
					see_next_tutorial();
				else
					if (option == 4)
						delete_tutorial_from_watch_list();
					else
						if (option == 5)
							see_watch_list();
						else
							std::cout << "Invalid input" << std::endl;

		print_user_mode_options();
		std::cin >> option;

	}
}

void choose_user_or_administrator_mode()
{
	std::cout << "Which mode would you like to use? " << std::endl;
	std::cout << "1. Administrator " << std::endl;
	std::cout << "2. User " << std::endl;
	std::cout << "3. Exit " << std::endl;
	int mode;
	std::cout << " > ";
	std::cin >> mode;
	while (mode != 3)
	{
		if (mode == 1)
			run_administrator_console();
		else
			if (mode == 2)
				run_user_console();
			else
				std::cout << "Invalid option" << std::endl;
		std::cout << "Which mode would you like to use? " << std::endl;
		std::cout << "1. Administrator " << std::endl;
		std::cout << "2. User " << std::endl;
		std::cout << "3. Exit " << std::endl;
		std::cout << " > ";
		std::cin >> mode;
	}

}
