#pragma once

#include "tutorials.h"

class string {};