#pragma once
#include "tutorials.h"
class TutorialValidator {
public:
    bool validate(const Tutorials& tutorial) const;
};
